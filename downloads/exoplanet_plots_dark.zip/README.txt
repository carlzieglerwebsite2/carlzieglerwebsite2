Carl Ziegler — The Growing Exoplanet Census
Static dark figures, 1991–2026

Data: NASA Exoplanet Archive Planetary Systems table, default_flag=1.
Each image has a radius–period panel and a mass–period panel.
White-edged points were discovered in the frame year; outlined diamonds are Solar System planets.

Interactive version: https://carlziegler.space/#exoplanet-explorer
Plotting code: https://github.com/carlzieglerwebsite2/carlzieglerwebsite2/tree/master/exoplanets
