Carl Ziegler — The Growing Exoplanet Census
Static dark figures, 1991–2026

Data: NASA Exoplanet Archive Planetary Systems table, default_flag=1.
Each image contains one period-versus-radius-equivalent plot.
Measured radii are filled points. If radius is absent but mass is measured, an open point uses the
Chen & Kipping (2017) Forecaster broken-power-law center as an approximate radius-equivalent.
That conversion has intrinsic scatter and is for population visualization, not a radius measurement.
White-edged filled points were discovered in the frame year; outlined diamonds are Solar System planets.

Interactive version: https://carlziegler.space/#exoplanet-explorer
Plotting code: https://github.com/carlzieglerwebsite2/carlzieglerwebsite2/tree/master/exoplanets
